import { createClient } from '@supabase/supabase-js'
import WebSocket from 'ws'
import { config, isSupabaseSyncConfigured } from './config.js'
import { createId, db, getBranchMeta, parseJson, nowIso, setBranchMeta } from './db.js'
import { getInventoryImportStatus, importInventorySnapshot } from './inventoryRepository.js'
import { getNhiaSummary, importNhiaConfigurationSnapshot } from './nhiaRepository.js'
import { importOfflineRecords, reconcileLocalNhisInventoryPolicyBaseline } from './offlineRecordsRepository.js'
import { streamSupabasePages } from './supabasePagination.js'
import {
  importMetadataSnapshot,
  importSalesSnapshot,
  importUsersSnapshot,
} from './cloudSnapshotRepository.js'
import { FAILURE_CATEGORIES, MAX_TRANSIENT_ATTEMPTS, classifySyncFailure, nextRetryAt } from './syncFailure.js'

const pendingOutbox = db.prepare(`
  SELECT *
  FROM sync_outbox
  WHERE status = 'pending'
     OR (
       status = 'failed'
       AND failure_category = 'TRANSIENT'
       AND manual_intervention_required = 0
       AND attempts < ?
       AND (next_retry_at IS NULL OR next_retry_at <= ?)
     )
  ORDER BY created_at ASC, rowid ASC
  LIMIT ?
`)

const markOutboxSyncing = db.prepare(`
  UPDATE sync_outbox
  SET status = 'syncing', attempts = attempts + 1, updated_at = ?
  WHERE id = ?
`)

const markOutboxSynced = db.prepare(`
  UPDATE sync_outbox
  SET status = 'synced', last_error = NULL, last_error_code = NULL, failure_category = NULL,
      last_error_at = NULL, next_retry_at = NULL, manual_intervention_required = 0,
      synced_at = ?, updated_at = ?
  WHERE id = ?
`)

const markOutboxFailed = db.prepare(`
  UPDATE sync_outbox
  SET status = 'failed', last_error = @message, last_error_code = @code,
      failure_category = @category, last_error_at = @timestamp, next_retry_at = @nextRetryAt,
      manual_intervention_required = @manual, updated_at = @timestamp
  WHERE id = @id
`)

const markSaleSynced = db.prepare(`
  UPDATE sales
  SET sync_status = 'synced',
      remote_sale_id = ?,
      remote_sale_number = ?,
      synced_at = ?,
      last_sync_error = NULL
  WHERE id = ?
`)

const markSaleFailed = db.prepare(`
  UPDATE sales
  SET sync_status = 'failed', last_sync_error = ?
  WHERE id = ?
`)

const markClaimSynced = db.prepare(`
  UPDATE claims
  SET sync_status = 'synced',
      remote_claim_id = ?,
      remote_claim_number = ?,
      synced_at = ?,
      last_sync_error = NULL
  WHERE id = ?
`)

const markClaimFailed = db.prepare(`
  UPDATE claims
  SET sync_status = 'failed', last_sync_error = ?
  WHERE id = ?
`)

const markOfflineRecordSynced = db.prepare(`
  UPDATE offline_records
  SET sync_status = 'synced',
      synced_at = ?,
      last_sync_error = NULL,
      updated_at = ?
  WHERE id = ?
    AND entity_type = ?
`)

const markOfflineRecordFailed = db.prepare(`
  UPDATE offline_records
  SET sync_status = 'failed',
      last_sync_error = ?,
      updated_at = ?
  WHERE id = ?
    AND entity_type = ?
`)

const reconcileSyncedOfflineRecords = db.prepare(`
  UPDATE offline_records
  SET sync_status = 'synced',
      synced_at = COALESCE((
        SELECT MAX(outbox.synced_at)
        FROM sync_outbox AS outbox
        WHERE outbox.entity_id = offline_records.id
          AND outbox.entity_type = offline_records.entity_type
          AND outbox.status = 'synced'
      ), ?),
      last_sync_error = NULL,
      updated_at = ?
  WHERE sync_status = 'failed'
    AND EXISTS (
      SELECT 1
      FROM sync_outbox AS outbox
      WHERE outbox.entity_id = offline_records.id
        AND outbox.entity_type = offline_records.entity_type
        AND outbox.status = 'synced'
    )
`)

export const reconcileSyncedOfflineRecordStatuses = () => {
  const timestamp = nowIso()
  return reconcileSyncedOfflineRecords.run(timestamp, timestamp).changes
}

let syncPendingOutboxPromise = null
let reconnectPromise = null

const createSupabaseClient = () => {
  if (!isSupabaseSyncConfigured()) {
    throw new Error('Supabase sync is not configured.')
  }

  return createClient(config.supabaseUrl, config.supabaseSyncKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
    realtime: {
      transport: WebSocket,
    },
  })
}

const getErrorMessage = (error) =>
  [
    error?.message,
    error?.cause?.message,
    error?.cause?.code,
    error?.cause?.errno,
    error?.cause?.syscall,
    error?.cause?.hostname,
  ]
    .filter(Boolean)
    .join(' | ')

const withSupabaseNetworkContext = async (operation) => {
  try {
    return await operation()
  } catch (error) {
    if (String(error?.message || '').toLowerCase().includes('fetch failed')) {
      throw new Error(`Unable to reach Supabase from this branch server: ${getErrorMessage(error)}`)
    }

    throw error
  }
}

const syncSaleCompleted = async (supabase, row) => {
  const payload = parseJson(row.payload_json)
  const { data, error } = await supabase.rpc('branch_sync_create_sale_transaction', {
    p_sync_token: config.branchSyncToken,
    p_local_sale_id: payload.local_sale_id || row.entity_id,
    sale_payload: payload.sale_payload,
  })

  if (error) {
    throw error
  }

  const timestamp = nowIso()
  markSaleSynced.run(
    data?.sale_id || null,
    data?.sale_number || null,
    timestamp,
    payload.local_sale_id || row.entity_id
  )
  markOutboxSynced.run(timestamp, timestamp, row.id)

  return {
    localId: payload.local_sale_id || row.entity_id,
    remoteId: data?.sale_id || null,
    remoteSaleNumber: data?.sale_number || null,
  }
}

const syncClaimSubmitted = async (supabase, row) => {
  const payload = parseJson(row.payload_json)
  const { data, error } = await supabase.rpc('branch_sync_create_claim_transaction', {
    p_sync_token: config.branchSyncToken,
    p_local_claim_id: payload.local_claim_id || row.entity_id,
    claim_payload: payload.claim_payload,
  })

  if (error) {
    throw error
  }

  const timestamp = nowIso()
  markClaimSynced.run(
    data?.claim_id || null,
    data?.claim_number || null,
    timestamp,
    payload.local_claim_id || row.entity_id
  )
  markOutboxSynced.run(timestamp, timestamp, row.id)

  return {
    localId: payload.local_claim_id || row.entity_id,
    remoteId: data?.claim_id || null,
    remoteClaimNumber: data?.claim_number || null,
  }
}

const syncNhisServingCompleted = async (supabase, row) => {
  const payload = parseJson(row.payload_json, {})
  const { data, error } = await supabase.rpc('branch_sync_complete_nhis_serving', {
    p_sync_token: config.branchSyncToken,
    p_local_event_id: payload.local_event_id || row.entity_id,
    p_claim_id: payload.claim_id,
    p_policy_enabled: payload.policy_enabled === true,
  })
  if (error) throw error
  const timestamp = nowIso()
  db.prepare('UPDATE local_nhis_serving_events SET synced_at = ? WHERE id = ?')
    .run(timestamp, payload.local_event_id || row.entity_id)
  // The cloud serving event is the authority. Allow the fresh inventory
  // snapshot below to replace this optimistic branch deduction.
  db.prepare(`
    UPDATE drugs SET sync_status = 'synced'
    WHERE id IN (
      SELECT drug_id FROM local_nhis_inventory_ledger
      WHERE serving_event_id = ?
    )
  `).run(payload.local_event_id || row.entity_id)
  markOutboxSynced.run(timestamp, timestamp, row.id)
  await pullInventorySnapshot({ forceFull: false })
  return { localId: payload.local_event_id || row.entity_id, remoteId: data?.event_id || null }
}

const syncNhiaConfiguration = async (supabase, row) => {
  const payload = parseJson(row.payload_json, {})
  const configPayload = payload.config || payload.record || {}
  const { data, error } = await supabase.rpc('branch_sync_upsert_nhia_configuration', {
    p_sync_token: config.branchSyncToken,
    p_config: configPayload,
  })

  if (error) {
    throw error
  }

  const timestamp = nowIso()
  markOutboxSynced.run(timestamp, timestamp, row.id)
  return {
    localId: row.entity_id,
    remoteId: data?.remote_id || row.entity_id,
  }
}

const stripLocalFields = (record, omit = []) => {
  const omitted = new Set([
    'local_id',
    'sync_status',
    'last_sync_error',
    'synced_at',
    ...omit,
  ])
  return Object.fromEntries(
    Object.entries(record || {}).filter(([, value]) => value !== undefined).filter(([key]) => !omitted.has(key))
  )
}

const syncNhisDrugUpsert = async (supabase, row, record) => {
  const { data, error } = await supabase.rpc('branch_sync_upsert_offline_record', {
    p_sync_token: config.branchSyncToken,
    p_entity_type: 'nhis_drugs',
    p_local_id: record.id,
    p_record: stripLocalFields(record),
  })

  if (error) {
    throw error
  }

  const timestamp = nowIso()
  markOfflineRecordSynced.run(timestamp, timestamp, record.id, 'nhis_drugs')
  if (row.entity_id !== record.id) {
    markOfflineRecordSynced.run(timestamp, timestamp, row.entity_id, 'nhis_drugs')
  }
  markOutboxSynced.run(timestamp, timestamp, row.id)
  return {
    localId: record.id,
    entityType: 'nhis_drugs',
    remoteId: data?.remote_id || record.id,
  }
}

const NHIS_PRESCRIBING_RECORD_ENTITIES = new Set([
  'nhis_prescribers',
  'nhis_prescribing_facilities',
])

const syncNhisPrescribingRecordUpsert = async (supabase, row, entityType, record) => {
  const { data, error } = await supabase.rpc('branch_sync_upsert_nhis_prescribing_record', {
    p_sync_token: config.branchSyncToken,
    p_entity_type: entityType,
    p_local_id: record.id,
    p_record: stripLocalFields(record),
  })

  if (error) {
    throw error
  }

  const timestamp = nowIso()
  markOfflineRecordSynced.run(timestamp, timestamp, record.id, entityType)
  if (row.entity_id !== record.id) {
    markOfflineRecordSynced.run(timestamp, timestamp, row.entity_id, entityType)
  }
  markOutboxSynced.run(timestamp, timestamp, row.id)
  return {
    localId: record.id,
    entityType,
    remoteId: data?.remote_id || record.id,
  }
}

const syncRecordUpsert = async (supabase, row) => {
  const payload = parseJson(row.payload_json, {})
  const entityType = payload.entity_type || row.entity_type
  const record = payload.record || {}
  const timestamp = nowIso()

  if (!record.id) {
    throw new Error('Offline record is missing an id.')
  }

  if (entityType === 'nhis_drugs') {
    return await syncNhisDrugUpsert(supabase, row, record)
  }

  if (NHIS_PRESCRIBING_RECORD_ENTITIES.has(entityType)) {
    return await syncNhisPrescribingRecordUpsert(supabase, row, entityType, record)
  }

  const { data, error } = await supabase.rpc('branch_sync_upsert_offline_record', {
    p_sync_token: config.branchSyncToken,
    p_entity_type: entityType,
    p_local_id: record.id,
    p_record: stripLocalFields(record),
  })

  if (error) {
    throw error
  }

  if (entityType === 'nhis_claims') {
    const remoteId = data?.remote_id || record.id
    const { error: verificationError } = await supabase
      .from('nhis_claims')
      .update({
        prescription_document_type: record.prescription_document_type || null,
        prescription_verified: record.prescription_verified === true,
        prescription_verified_by: record.prescription_verified_by || null,
        prescription_verified_at: record.prescription_verified_at || null,
      })
      .eq('id', remoteId)

    if (verificationError) {
      throw verificationError
    }
  }

  markOfflineRecordSynced.run(timestamp, timestamp, record.id, entityType)
  if (row.entity_id !== record.id) {
    markOfflineRecordSynced.run(timestamp, timestamp, row.entity_id, entityType)
  }
  markOutboxSynced.run(timestamp, timestamp, row.id)
  return {
    localId: record.id,
    entityType,
    remoteId: data?.remote_id || record.id,
  }
}

const syncRecordDelete = async (supabase, row) => {
  const payload = parseJson(row.payload_json, {})
  const entityType = payload.entity_type || row.entity_type
  const localId = payload.local_id || row.entity_id
  const { data, error } = await supabase.rpc('branch_sync_delete_offline_record', {
    p_sync_token: config.branchSyncToken,
    p_entity_type: entityType,
    p_local_id: localId,
  })

  if (error) throw error

  const timestamp = nowIso()
  markOutboxSynced.run(timestamp, timestamp, row.id)
  return {
    localId,
    entityType,
    deleted: Boolean(data?.deleted),
  }
}

const runPendingOutboxSync = async ({ limit = 25 } = {}) => {
  const supabase = createSupabaseClient()
  const rows = pendingOutbox.all(
    MAX_TRANSIENT_ATTEMPTS,
    nowIso(),
    Math.min(Math.max(Number(limit) || 25, 1), 1000)
  )
  const result = { synced: 0, failed: 0, total: rows.length, errors: [] }

  for (const row of rows) {
    const timestamp = nowIso()
    markOutboxSyncing.run(timestamp, row.id)

    try {
      if (row.event_type === 'sale.completed') {
        await syncSaleCompleted(supabase, row)
        result.synced += 1
      } else if (row.event_type === 'claim.submitted') {
        await syncClaimSubmitted(supabase, row)
        result.synced += 1
      } else if (row.event_type === 'nhis.serving.completed') {
        await syncNhisServingCompleted(supabase, row)
        result.synced += 1
      } else if (row.event_type === 'nhia_config.updated') {
        await syncNhiaConfiguration(supabase, row)
        result.synced += 1
      } else if (row.event_type === 'record.upsert') {
        await syncRecordUpsert(supabase, row)
        result.synced += 1
      } else if (row.event_type === 'record.delete') {
        await syncRecordDelete(supabase, row)
        result.synced += 1
      } else {
        throw new Error(`Unsupported sync event type: ${row.event_type}`)
      }
    } catch (error) {
      const message = error.message || 'Sync failed.'
      const failure = classifySyncFailure(error)
      const attemptCount = Number(row.attempts || 0) + 1
      const attemptsExhausted = failure.category === FAILURE_CATEGORIES.TRANSIENT && attemptCount >= MAX_TRANSIENT_ATTEMPTS
      const category = attemptsExhausted ? FAILURE_CATEGORIES.MANUAL_INTERVENTION : failure.category
      const manual = attemptsExhausted || failure.manual
      markOutboxFailed.run({
        message,
        code: failure.code,
        category,
        timestamp: nowIso(),
        nextRetryAt: category === FAILURE_CATEGORIES.TRANSIENT ? nextRetryAt(attemptCount) : null,
        manual: manual ? 1 : 0,
        id: row.id,
      })
      if (row.entity_type === 'sales') {
        markSaleFailed.run(message, row.entity_id)
      } else if (row.entity_type === 'claims') {
        markClaimFailed.run(message, row.entity_id)
        markOfflineRecordFailed.run(message, nowIso(), row.entity_id, row.entity_type)
      } else if (row.entity_type === 'nhia_configuration') {
        // The outbox row carries the retry state for configuration sync.
      } else {
        markOfflineRecordFailed.run(message, nowIso(), row.entity_id, row.entity_type)
      }
      result.failed += 1
      result.errors.push({ id: row.id, eventType: row.event_type, message, category })
    }
  }

  return result
}

export const syncPendingOutbox = async (options = {}) => {
  if (syncPendingOutboxPromise) {
    return syncPendingOutboxPromise
  }

  syncPendingOutboxPromise = runPendingOutboxSync(options)
  try {
    return await syncPendingOutboxPromise
  } finally {
    syncPendingOutboxPromise = null
  }
}

export const getSyncStatus = () => {
  const rows = db.prepare(`
    SELECT status, COUNT(*) AS count
    FROM sync_outbox
    GROUP BY status
  `).all()
  const offlineRows = db.prepare(`
    SELECT entity_type, sync_status, COUNT(*) AS count
    FROM offline_records
    GROUP BY entity_type, sync_status
    ORDER BY entity_type, sync_status
  `).all()
  const eventRows = db.prepare(`
    SELECT event_type, status, COUNT(*) AS count
    FROM sync_outbox
    GROUP BY event_type, status
    ORDER BY event_type, status
  `).all()
  const failedRecords = db.prepare(`
    SELECT id, entity_type, last_sync_error, updated_at
    FROM offline_records
    WHERE sync_status = 'failed'
    ORDER BY updated_at DESC
    LIMIT 10
  `).all()
  const failedEvents = db.prepare(`
    SELECT id, event_type, entity_type, entity_id, last_error, last_error_code,
           failure_category, last_error_at, next_retry_at, manual_intervention_required,
           attempts, created_at, updated_at
    FROM sync_outbox
    WHERE status = 'failed'
    ORDER BY updated_at DESC
    LIMIT 10
  `).all()

  const status = rows.reduce(
    (status, row) => {
      status[row.status] = row.count
      status.total += row.count
      return status
    },
    { pending: 0, syncing: 0, failed: 0, synced: 0, total: 0 }
  )
  const recordsByEntity = offlineRows.reduce((summary, row) => {
    if (!summary[row.entity_type]) {
      summary[row.entity_type] = { pending: 0, failed: 0, synced: 0, total: 0 }
    }
    summary[row.entity_type][row.sync_status] = row.count
    summary[row.entity_type].total += row.count
    return summary
  }, {})
  const eventsByType = eventRows.reduce((summary, row) => {
    if (!summary[row.event_type]) {
      summary[row.event_type] = { pending: 0, syncing: 0, failed: 0, synced: 0, total: 0 }
    }
    summary[row.event_type][row.status] = row.count
    summary[row.event_type].total += row.count
    return summary
  }, {})

  return {
    ...status,
    recordsByEntity,
    eventsByType,
    recentFailures: {
      records: failedRecords,
      events: failedEvents,
    },
    inventory: getInventoryImportStatus(),
    referenceData: {
      lastPulledAt: getBranchMeta('reference_data_last_pulled_at'),
    },
    nhia: getNhiaSummary(),
    lastSuccessfulCloudSyncAt: db.prepare(`
      SELECT MAX(synced_at) FROM sync_outbox WHERE status = 'synced'
    `).pluck().get() || null,
    oldestPendingEventAt: db.prepare(`
      SELECT MIN(created_at) FROM sync_outbox WHERE status IN ('pending', 'syncing')
    `).pluck().get() || null,
    oldestFailedEventAt: db.prepare(`
      SELECT MIN(created_at) FROM sync_outbox WHERE status = 'failed'
    `).pluck().get() || null,
  }
}

export const listSyncIssues = ({ limit = 100 } = {}) => db.prepare(`
  SELECT id, event_type, entity_type, entity_id, status, attempts, created_at, updated_at,
         last_error, last_error_code, failure_category, last_error_at, next_retry_at,
         manual_intervention_required
  FROM sync_outbox
  WHERE status = 'failed'
  ORDER BY COALESCE(last_error_at, updated_at) DESC
  LIMIT ?
`).all(Math.min(Math.max(Number(limit) || 100, 1), 500))

export const retrySyncIssue = ({ id, actorUserId }) => {
  const event = db.prepare('SELECT id FROM sync_outbox WHERE id = ? AND status = ?').get(id, 'failed')
  if (!event) throw new Error('Failed sync issue not found.')
  const timestamp = nowIso()
  db.transaction(() => {
    db.prepare(`UPDATE sync_outbox
      SET status = 'pending', next_retry_at = NULL, manual_intervention_required = 0, updated_at = ?
      WHERE id = ?`).run(timestamp, id)
    db.prepare('INSERT INTO sync_retry_audit (id, outbox_id, actor_user_id, created_at) VALUES (?, ?, ?, ?)')
      .run(createId(), id, actorUserId, timestamp)
  })()
  return { id, status: 'pending', retriedAt: timestamp }
}

export const pullInventorySnapshot = async ({ forceFull = false } = {}) => {
  const supabase = createSupabaseClient()
  const inventoryStatus = getInventoryImportStatus()
  const { data, error } = await withSupabaseNetworkContext(() =>
    supabase.rpc('branch_sync_get_inventory_snapshot', {
      p_sync_token: config.branchSyncToken,
      p_limit: 20000,
      p_updated_since: forceFull ? null : inventoryStatus.lastInventoryImportAt || null,
    })
  )

  if (error) {
    throw error
  }

  const result = importInventorySnapshot(data?.drugs || [])
  return {
    ...result,
    branchId: data?.branch_id || null,
    organizationId: data?.organization_id || null,
    pulledAt: data?.pulled_at || null,
  }
}

const importAll = async (
  supabase,
  table,
  importer,
  select = '*',
  organizationColumn = 'organization_id'
) => {
  let imported = 0
  await streamSupabasePages({
    createQuery: () => {
      let query = supabase.from(table).select(select)
      if (config.organizationId && organizationColumn) {
        query = query.eq(organizationColumn, config.organizationId)
      }
      return query
    },
    onPage: (page) => {
      imported += Number(importer(page)?.imported || 0)
    },
  })
  return imported
}

const importOptionalAll = async (
  supabase,
  table,
  importer,
  select = '*',
  organizationColumn = 'organization_id'
) => {
  try {
    return await importAll(supabase, table, importer, select, organizationColumn)
  } catch (error) {
    if (['42P01', 'PGRST205'].includes(error?.code)) {
      return 0
    }
    throw error
  }
}

const importNhisClaims = async (supabase) => {
  const selectWithServices = '*, nhis_claim_medicines (*), nhis_claim_services (*)'
  const importer = (page) => importOfflineRecords('nhis_claims', page)

  try {
    return await importAll(supabase, 'nhis_claims', importer, selectWithServices)
  } catch (error) {
    const message = String(error?.message || '')
    const missingServicesRelation =
      ['42P01', 'PGRST200', 'PGRST205'].includes(error?.code) ||
      message.includes('nhis_claim_services')

    if (!missingServicesRelation) {
      throw error
    }

    return importAll(supabase, 'nhis_claims', importer, '*, nhis_claim_medicines (*)')
  }
}

export const pullReferenceData = async () => {
  const supabase = createSupabaseClient()
  const result = {
    pulledAt: nowIso(),
    patients: 0,
    suppliers: 0,
    claims: 0,
    nhisDrugs: 0,
    nhisClinicalRules: 0,
    nhiaTariffItems: 0,
    nhisPrescribers: 0,
    nhisPrescribingFacilities: 0,
    nhisClaims: 0,
    nhiaConfigurations: 0,
    purchases: 0,
    sales: 0,
    staff: 0,
    branches: 0,
    organizations: 0,
    settings: 0,
  }

  const [
    patients,
    suppliers,
    claims,
    nhisDrugs,
    nhisClinicalRules,
    nhiaTariffItems,
    nhisPrescribers,
    nhisPrescribingFacilities,
    nhisClaims,
    nhiaConfigurations,
    purchases,
    sales,
    staff,
    branches,
    organizations,
    settings,
  ] =
    await withSupabaseNetworkContext(() =>
      Promise.all([
        importAll(supabase, 'patients', (page) => importOfflineRecords('patients', page)),
        importAll(supabase, 'suppliers', (page) => importOfflineRecords('suppliers', page)),
        importAll(
          supabase,
          'claims',
          (page) => importOfflineRecords('claims', page),
          '*, claim_items (*)'
        ),
        importAll(supabase, 'nhis_drugs', (page) => importOfflineRecords('nhis_drugs', page)),
        // Shared national catalogues: they have no organization_id column, so they are not filtered by organisation.
        importOptionalAll(
          supabase,
          'nhis_clinical_rules',
          (page) => importOfflineRecords('nhis_clinical_rules', page),
          '*',
          null
        ),
        importOptionalAll(
          supabase,
          'nhia_tariff_items',
          (page) => importOfflineRecords('nhia_tariff_items', page),
          '*',
          null
        ),
        importOptionalAll(
          supabase,
          'nhis_prescribers',
          (page) => importOfflineRecords('nhis_prescribers', page)
        ),
        importOptionalAll(
          supabase,
          'nhis_prescribing_facilities',
          (page) => importOfflineRecords('nhis_prescribing_facilities', page)
        ),
        importNhisClaims(supabase),
        importOptionalAll(
          supabase,
          'nhia_configuration',
          importNhiaConfigurationSnapshot
        ),
        importAll(
          supabase,
          'purchases',
          (page) => importOfflineRecords('purchases', page),
          '*, purchase_items (*)'
        ),
        importAll(supabase, 'sales', importSalesSnapshot, '*, sale_items (*)'),
        importAll(supabase, 'users', importUsersSnapshot),
        importAll(
          supabase,
          'branches',
          (page) => importMetadataSnapshot('branches_snapshot', page)
        ),
        importAll(
          supabase,
          'organizations',
          (page) => importMetadataSnapshot('organization_snapshot', page),
          '*',
          'id'
        ),
        importOptionalAll(
          supabase,
          'pharmacy_settings',
          (page) => importMetadataSnapshot('pharmacy_settings_snapshot', page)
        ),
      ])
    )

  result.patients = patients
  result.suppliers = suppliers
  result.claims = claims
  result.nhisDrugs = nhisDrugs
  result.nhisClinicalRules = nhisClinicalRules
  result.nhiaTariffItems = nhiaTariffItems
  result.nhisPrescribers = nhisPrescribers
  result.nhisPrescribingFacilities = nhisPrescribingFacilities
  result.nhisClaims = nhisClaims
  result.nhiaConfigurations = nhiaConfigurations
  result.purchases = purchases
  result.sales = sales
  result.staff = staff
  result.branches = branches
  result.organizations = organizations
  result.settings = settings
  reconcileLocalNhisInventoryPolicyBaseline()
  setBranchMeta('operational_data_last_pulled_at', result.pulledAt)
  setBranchMeta('reference_data_last_pulled_at', result.pulledAt)

  const { error: protocolError } = await supabase.rpc('branch_sync_report_nhis_inventory_protocol', {
    p_sync_token: config.branchSyncToken,
    p_protocol_version: 1,
  })
  if (protocolError) {
    const code = String(protocolError.code || '')
    const message = String(protocolError.message || '')
    // During a staged rollout an older cloud schema has no attestation RPC.
    // Do not break the read-only reference pull; its version remains blocked
    // from enabling the policy until this protocol call succeeds later.
    if (!['42883', 'PGRST202', 'PGRST205'].includes(code) && !/could not find.*function|does not exist/i.test(message)) {
      throw protocolError
    }
    console.warn('NHIS inventory protocol attestation is unavailable until the cloud migration is applied.')
  }

  return result
}

export const repairFailedSync = async ({ limit = 1000 } = {}) => {
  const sync = await syncPendingOutbox({ limit })
  const reconciledRecords = reconcileSyncedOfflineRecordStatuses()
  const [inventory, reference] = await Promise.all([
    pullInventorySnapshot({ forceFull: true }),
    pullReferenceData(),
  ])

  return {
    repairedAt: nowIso(),
    sync,
    reconciledRecords,
    inventory,
    reference,
    status: getSyncStatus(),
  }
}

export const validateCloudBranchSession = async () => {
  const supabase = createSupabaseClient()
  const { data, error } = await withSupabaseNetworkContext(() =>
    supabase.rpc('branch_sync_get_inventory_snapshot', {
      p_sync_token: config.branchSyncToken,
      p_limit: 1,
      p_updated_since: null,
    })
  )
  if (error) throw error
  if (
    (config.organizationId && data?.organization_id !== config.organizationId) ||
    (config.branchId && data?.branch_id !== config.branchId)
  ) {
    throw new Error('Cloud branch identity does not match this branch server configuration.')
  }
  return { organizationId: data?.organization_id || null, branchId: data?.branch_id || null }
}

const runReconnectAndReconcile = async ({ limit = 1000 } = {}) => {
  const startedAt = nowIso()
  const before = getSyncStatus()
  const identity = await validateCloudBranchSession()
  const sync = await syncPendingOutbox({ limit })
  const reconciledRecords = reconcileSyncedOfflineRecordStatuses()
  const inventory = await pullInventorySnapshot({ forceFull: true })
  const reference = await pullReferenceData()
  const status = getSyncStatus()
  return {
    startedAt,
    completedAt: nowIso(),
    identity,
    before,
    sync,
    reconciledRecords,
    inventory,
    reference,
    status,
    state: status.failed > 0 ? 'ACTION_REQUIRED' : status.pending > 0 ? 'DEGRADED' : 'HEALTHY',
  }
}

export const reconnectAndReconcile = async (options = {}) => {
  if (reconnectPromise) return reconnectPromise
  reconnectPromise = runReconnectAndReconcile(options)
  try {
    return await reconnectPromise
  } finally {
    reconnectPromise = null
  }
}

export const getSupabaseDiagnostics = async () => {
  const startedAt = nowIso()
  const diagnostics = {
    startedAt,
    supabaseUrlConfigured: Boolean(config.supabaseUrl),
    supabaseSyncKeyConfigured: Boolean(config.supabaseSyncKey),
    branchSyncTokenConfigured: Boolean(config.branchSyncToken),
    supabaseUrl: config.supabaseUrl || null,
    reachable: false,
    status: null,
    error: null,
  }

  if (!config.supabaseUrl) {
    diagnostics.error = 'SUPABASE_URL is not configured.'
    return diagnostics
  }

  try {
    const response = await fetch(`${config.supabaseUrl.replace(/\/+$/, '')}/rest/v1/`, {
      headers: {
        apikey: config.supabaseSyncKey,
        Authorization: `Bearer ${config.supabaseSyncKey}`,
      },
    })
    diagnostics.reachable = true
    diagnostics.status = response.status
  } catch (error) {
    diagnostics.error = getErrorMessage(error) || 'Unable to reach Supabase.'
  }

  return diagnostics
}
