// @vitest-environment node
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { pathToFileURL } from 'node:url'
import { describe, expect, it } from 'vitest'

describe('offline record outbox coalescing', () => {
  it('keeps one pending upsert with the latest local record payload', () => {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'healthflow-record-outbox-'))
    const databaseUrl = pathToFileURL(path.resolve('local-branch-server/src/db.js')).href
    const recordsUrl = pathToFileURL(path.resolve('local-branch-server/src/offlineRecordsRepository.js')).href
    const script = `
      const { db, closeDatabase, parseJson } = await import(${JSON.stringify(databaseUrl)});
      const { saveOfflineRecord } = await import(${JSON.stringify(recordsUrl)});
      saveOfflineRecord('patients', { id: 'patient-1', full_name: 'Before' });
      saveOfflineRecord('patients', { id: 'patient-1', full_name: 'After' });
      const rows = db.prepare("SELECT payload_json FROM sync_outbox WHERE entity_type = 'patients' AND entity_id = 'patient-1' AND event_type = 'record.upsert'").all();
      console.log(JSON.stringify({ count: rows.length, name: parseJson(rows[0].payload_json).record.full_name }));
      closeDatabase();
    `
    try {
      const output = execFileSync(process.execPath, ['--input-type=module', '--eval', script], {
        cwd: path.resolve('local-branch-server'),
        env: { ...process.env, HEALTHFLOW_DB_PATH: path.join(directory, 'branch.sqlite') },
        encoding: 'utf8',
      })
      expect(JSON.parse(output.trim().split(/\r?\n/).at(-1))).toEqual({ count: 1, name: 'After' })
    } finally {
      fs.rmSync(directory, { recursive: true, force: true })
    }
  })

  it('blocks offline serving without modifying imported history, stock or serving outbox', () => {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'healthflow-nhis-inventory-'))
    const databaseUrl = pathToFileURL(path.resolve('local-branch-server/src/db.js')).href
    const recordsUrl = pathToFileURL(path.resolve('local-branch-server/src/offlineRecordsRepository.js')).href
    const script = `
      const { db, closeDatabase, setBranchMeta, parseJson } = await import(${JSON.stringify(databaseUrl)});
      const { saveOfflineRecord, importOfflineRecords, getOfflineRecord, queueNhisServingSync, reconcileLocalNhisInventoryPolicyBaseline } = await import(${JSON.stringify(recordsUrl)});
      saveOfflineRecord('nhis_claims', { id: 'draft-ccc', status: 'draft', ccc_no: '', prescription_file_path: 'fixture.pdf' });
      const before = db.prepare('SELECT COUNT(*) FROM sync_outbox').pluck().get();
      let rejected = 0;
      try { saveOfflineRecord('nhis_claims', { id: 'draft-ccc', status: 'served', ccc_no: '' }); } catch (error) { if (error.code === 'NHIS_CCC_REQUIRED') rejected++; else throw error; }
      try { queueNhisServingSync({ id: 'draft-ccc', ccc_no: '' }); } catch (error) { if (error.code === 'NHIS_CCC_REQUIRED') rejected++; else throw error; }
      if (rejected !== 2 || db.prepare('SELECT COUNT(*) FROM sync_outbox').pluck().get() !== before) throw new Error('Invalid CCC changed offline outbox');
      const initial = { id: 'claim-1', ccc_no: '12345', updated_at: '2026-09-07T10:00:00.000Z', nhis_claim_medicines: [{ drug_code: 'NHIS-1', duration: '2 weeks', served_qty: 3 }] };
      importOfflineRecords('nhis_claims', [initial]);
      const snapshot = getOfflineRecord('nhis_claims', initial.id);
      if (snapshot.nhis_claim_medicines[0].duration !== '2 weeks') throw new Error('Snapshot lost duration');
      let onlineRequired = false;
      try { saveOfflineRecord('nhis_claims', snapshot); } catch (error) { if (error.code === 'NHIS_ONLINE_SERVING_REQUIRED') onlineRequired = true; else throw error; }
      if (!onlineRequired) throw new Error('Offline served write was accepted');
      let durationRejected = false;
      try { saveOfflineRecord('nhis_claims', { ...initial, nhis_claim_medicines: [{ ...initial.nhis_claim_medicines[0], duration: '' }] }); } catch (error) { if (error.code === 'NHIS_DURATION_REQUIRED') durationRejected = true; else throw error; }
      if (!durationRejected) throw new Error('Missing duration reached offline outbox');
      db.prepare("INSERT INTO drugs (id, name, quantity, price, nhis_code, updated_at) VALUES ('drug-1', 'Test', 10, 1, 'NHIS-1', '2026-09-07T10:00:00.000Z')").run();
      setBranchMeta('pharmacy_settings_snapshot', JSON.stringify([{ nhis_deduct_inventory_on_serve: true }]));
      reconcileLocalNhisInventoryPolicyBaseline();
      try { queueNhisServingSync(initial); throw new Error('Serving was allowed'); } catch (error) { if (error.code !== 'NHIS_ONLINE_SERVING_REQUIRED') throw error; }
      const next = { ...initial, updated_at: '2026-09-07T10:01:00.000Z', nhis_claim_medicines: [{ drug_code: 'NHIS-1', duration: '2 weeks', served_qty: 5 }] };
      try { queueNhisServingSync(next); throw new Error('Serving was allowed'); } catch (error) { if (error.code !== 'NHIS_ONLINE_SERVING_REQUIRED') throw error; }
      if (db.prepare("SELECT COUNT(*) FROM sync_outbox WHERE event_type='nhis.serving.completed'").pluck().get() !== 0) throw new Error('Offline serving was queued');
      const quantity = db.prepare("SELECT quantity FROM drugs WHERE id = 'drug-1'").pluck().get();
      const ledger = db.prepare('SELECT COALESCE(SUM(-quantity_delta), 0) FROM local_nhis_inventory_ledger').pluck().get();
      console.log(JSON.stringify({ quantity, ledger }));
      closeDatabase();
    `
    try {
      const output = execFileSync(process.execPath, ['--input-type=module', '--eval', script], {
        cwd: path.resolve('local-branch-server'),
        env: { ...process.env, HEALTHFLOW_DB_PATH: path.join(directory, 'branch.sqlite') },
        encoding: 'utf8',
      })
      expect(JSON.parse(output.trim().split(/\r?\n/).at(-1))).toEqual({ quantity: 10, ledger: 0 })
    } finally {
      fs.rmSync(directory, { recursive: true, force: true })
    }
  })
})

it('blocks exact offline duplicates atomically while permitting different members, service dates and totals', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'healthflow-ccc-guard-'))
  const databaseUrl = pathToFileURL(path.resolve('local-branch-server/src/db.js')).href
  const recordsUrl = pathToFileURL(path.resolve('local-branch-server/src/offlineRecordsRepository.js')).href
  const script = `
    const { db, closeDatabase } = await import(${JSON.stringify(databaseUrl)});
    const { saveOfflineRecord } = await import(${JSON.stringify(recordsUrl)});
    const original = { id: 'original', member_no: '12345678', ccc_no: '12345', service_date_from: '2026-10-01', total_amount: 100, status: 'draft' };
    saveOfflineRecord('nhis_claims', original);
    const before = db.prepare('select count(*) from sync_outbox').pluck().get();
    let blocked = false;
    try { saveOfflineRecord('nhis_claims', { ...original, id: 'duplicate' }); }
    catch (error) { if (error.code === 'NHIS_CCC_DUPLICATE') blocked = true; else throw error; }
    if (!blocked || db.prepare('select count(*) from sync_outbox').pluck().get() !== before) throw new Error('Duplicate write reached outbox');
    saveOfflineRecord('nhis_claims', { ...original, id: 'second-prescription', total_amount: 40 });
    saveOfflineRecord('nhis_claims', { ...original, id: 'other-member', member_no: '87654321' });
    saveOfflineRecord('nhis_claims', { ...original, id: 'other-date', service_date_from: '2026-10-02' });
    saveOfflineRecord('nhis_claims', { ...original, id: 'rejected', status: 'rejected' });
    saveOfflineRecord('nhis_claims', { ...original, notes: 'Self update' });
    closeDatabase();
    console.log('ok');
  `
  try {
    const output = execFileSync(process.execPath, ['--input-type=module', '--eval', script], {
      cwd: path.resolve('local-branch-server'), env: { ...process.env, HEALTHFLOW_DB_PATH: path.join(directory, 'branch.sqlite') }, encoding: 'utf8',
    })
    expect(output.trim().split(/\r?\n/).at(-1)).toBe('ok')
  } finally { fs.rmSync(directory, { recursive: true, force: true }) }
})
